# Courier Service Apps

## Overview of the Courier Service Apps

### Driver App (description)

#### Order Items

The driver can view the list of orders.

- Restaurant name
- Restaurant image
- Restaurant address
- Customer name
- Customer address
- Accept Button that opens the order route details

#### Order Pick Up Page

- Restaurant name
- Restaurant address
- Order address
- Order details
- Button to accept, pick-up and finish the order
