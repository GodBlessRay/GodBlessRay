# courier-service-apps

## Overview of the Courier Service Apps

### Customer App (description)

#### Resturant Items

 The customer can view the list of items in the restaurant.

- Image
- Title
- Rating
- Delivery time
- Delivery fee
- Pressable item

#### Restaurant Details Page

- Image with LinearGradient
- Title
- Rating
- Delivery fee
- Back button
- Basket icon button

#### Menu Items

- Title
- Description
- Price
- Pressable item

#### Menu Item Details Page

- Title
- Description
- Buttons for quantity
- State for quantity
- Button for adding to basket

#### Basket Page

- Title
- Quantity
- Price
- Restaurant title
- Back button
- Items list
- Subtotal/Total price
- Pay buttons

#### Order Page

Renders the order details.
